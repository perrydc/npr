Self-authenticating module for accessing NPR APIs in Python.


